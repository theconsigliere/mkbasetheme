=== Advanced Custom Fields: Star Rating Field ===
Contributors: Kevin Ruscoe
Tags: star, rating
Requires at least: 3.5
Tested up to: 3.8.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple star rating field for ACF.

== A simple star rating field for ACF. ==

A simple star rating field for ACF.

= Compatibility =

This ACF field type is compatible with:
* ACF 5

== Installation ==

1. Copy the report into your `wp-content/plugins` folder
2. Activate the Star Rating plugin via the plugins admin page
3. Create a new field via ACF and select the Star Rating type